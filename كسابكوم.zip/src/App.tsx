import React, { useState, useEffect } from 'react';
import { Minus, ChevronUp } from 'lucide-react';
import { AuthProvider } from './contexts/AuthContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { useSettings } from './hooks/useSettings';
import Home from './views/Home';
import SearchResults from './views/SearchResults';
import Auth from './views/Auth';
import BuyerDashboard from './views/BuyerDashboard';
import SellerDashboard from './views/SellerDashboard';
import AddListing from './views/AddListing';
import AdminDashboard from './views/AdminDashboard';
import AdminAuth from './views/AdminAuth';
import ListingDetails from './views/ListingDetails';
import SolidarityRequest from './views/SolidarityRequest';
import SolidarityDonate from './views/SolidarityDonate';
import PriceCatalog from './views/PriceCatalog';
import TipsPage from './views/TipsPage';
import ContactPage from './views/ContactPage';
import TermsPage from './views/TermsPage';
import PrivacyPage from './views/PrivacyPage';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

import { firestoreService } from './services/firestoreService';
import { useAuth } from './contexts/AuthContext';
import Maintenance from './views/Maintenance';
import LoadingScreen from './components/LoadingScreen';

export type ViewType = 'home' | 'auth' | 'admin-auth' | 'buyer' | 'seller' | 'add-listing' | 'admin' | 'listing-details' | 'search-results' | 'solidarity-request' | 'solidarity-donate' | 'price-catalog' | 'tips' | 'contact' | 'terms' | 'privacy';

function AppContent() {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [isAppReady, setIsAppReady] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setIsAppReady(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  const [selectedListingId, setSelectedListingId] = useState<string | undefined>(undefined);
  const [searchCity, setSearchCity] = useState<string | undefined>(undefined);
  const [searchRadius, setSearchRadius] = useState<string | undefined>(undefined);
  const [activeSubView, setActiveSubView] = useState<string | undefined>(undefined);
  const [intendedView, setIntendedView] = useState<{view: ViewType, listingId?: string} | null>(null);
  const [isDevNavMinimized, setIsDevNavMinimized] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const { settings, updateSettings } = useSettings();
  const { profile, loading: authLoading, user } = useAuth();

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      return;
    }
    const unsub = firestoreService.subscribeToUserNotifications(user.uid, setNotifications);
    return () => unsub();
  }, [user]);

  // Handle secret admin access via URL path
  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/panelaccess') {
      setCurrentView('admin-auth');
      // Only clean up the URL if it's a bare access, not a sign-in link
      if (!window.location.search.includes('oobCode')) {
        window.history.replaceState({}, '', '/');
      }
    }
  }, []);

  const handleNavigate = (view: ViewType, listingId?: string, city?: string, radius?: string, subView?: string) => {
    setCurrentView(view);
    setSelectedListingId(listingId);
    setSearchCity(city);
    setSearchRadius(radius);
    setActiveSubView(subView);
    if (view !== 'auth') {
      setIntendedView(null);
    }
  };

  // Handle redirection if solidarity feature is disabled
  useEffect(() => {
    if (!settings.solidarityDonationEnabled && (currentView === 'solidarity-request' || currentView === 'solidarity-donate')) {
      setCurrentView('home');
    }
  }, [settings.solidarityDonationEnabled, currentView]);

  // Handle maintenance mode and activation date
  useEffect(() => {
    if (settings.maintenanceMode && settings.activationDate) {
      const activationTime = new Date(settings.activationDate).getTime();
      const now = new Date().getTime();
      
      if (now >= activationTime) {
        updateSettings({ maintenanceMode: false, activationDate: null });
      }
    }
  }, [settings.maintenanceMode, settings.activationDate, updateSettings]);

  // Role-based and Authentication access restrictions
  useEffect(() => {
    if (!authLoading) {
      const protectedViews: ViewType[] = ['buyer', 'seller', 'admin', 'add-listing', 'solidarity-request', 'solidarity-donate'];
      
      // If guestBuyerMode is OFF, listing-details also becomes protected
      if (!settings.guestBuyerMode) {
        protectedViews.push('listing-details');
      }
      
      if (protectedViews.includes(currentView) && !profile) {
        if (currentView !== 'auth' && currentView !== 'admin-auth') {
          setIntendedView({ view: currentView, listingId: selectedListingId });
        }
        
        if (currentView === 'admin') {
          setCurrentView('admin-auth');
        } else {
          setCurrentView('auth');
        }
        return;
      }

      if (profile) {
        if (intendedView) {
          setCurrentView(intendedView.view);
          setSelectedListingId(intendedView.listingId);
          setIntendedView(null);
          return;
        }

        if (currentView === 'auth') {
          if (profile.role === 'admin') setCurrentView('admin');
          else if (profile.role === 'seller') setCurrentView('seller');
          else setCurrentView('buyer');
          return;
        }

        // Fix: If user is admin and currentView is seller or buyer, they might be trying to see their own dashboard
        // But if they click "Dashboard" from the menu, it should go to their primary role dashboard.
        // The issue reported is that navigating back to dashboard shows Kessab instead of Admin.
        // This usually happens if the navigation link points to 'seller' or 'buyer' instead of 'admin'.
        
        if (currentView === 'admin' && profile.role !== 'admin') {
          setCurrentView('home');
        }
        if (currentView === 'seller' && profile.role !== 'seller' && profile.role !== 'admin') {
          setCurrentView('home');
        }
        if (currentView === 'buyer' && profile.role !== 'buyer' && profile.role !== 'admin') {
          setCurrentView('home');
        }
      }
    }
  }, [profile, currentView, authLoading, settings.guestBuyerMode, intendedView, selectedListingId]);

  if (settings.maintenanceMode && profile?.role !== 'admin' && currentView !== 'admin-auth') {
    return <Maintenance activationDate={settings.activationDate} onNavigate={handleNavigate} />;
  }

  const renderView = () => {
    const protectedViews: ViewType[] = ['buyer', 'seller', 'admin', 'add-listing', 'solidarity-request', 'solidarity-donate'];
    if (!settings.guestBuyerMode) {
      protectedViews.push('listing-details');
    }
    
    // If auth is loading, show a loading state or nothing
    if (authLoading || !isAppReady) {
      return <LoadingScreen />;
    }

    // If trying to access a protected view without being logged in, redirect to auth
    if (protectedViews.includes(currentView) && !profile) {
      return <Auth onNavigate={handleNavigate} intendedView={intendedView} />;
    }

    if (currentView === 'admin-auth') {
      return <AdminAuth onNavigate={handleNavigate} />;
    }

    switch (currentView) {
      case 'home': return <Home onNavigate={handleNavigate} />;
      case 'auth': return <Auth onNavigate={handleNavigate} intendedView={intendedView} />;
      case 'admin-auth': return <AdminAuth onNavigate={handleNavigate} />;
      case 'buyer': return <BuyerDashboard onNavigate={handleNavigate} activeSubView={activeSubView} />;
      case 'seller': return <SellerDashboard onNavigate={handleNavigate} activeSubView={activeSubView} />;
      case 'add-listing': return <AddListing onNavigate={handleNavigate} listingId={selectedListingId} />;
      case 'admin': return <AdminDashboard onNavigate={handleNavigate} activeSubView={activeSubView} />;
      case 'listing-details': return <ListingDetails onNavigate={handleNavigate} listingId={selectedListingId} />;
      case 'search-results': return <SearchResults onNavigate={handleNavigate} initialCity={searchCity} initialRadius={searchRadius} />;
      case 'solidarity-request': return <SolidarityRequest onNavigate={handleNavigate} />;
      case 'solidarity-donate': return <SolidarityDonate onNavigate={handleNavigate} />;
      case 'price-catalog': return <PriceCatalog onNavigate={handleNavigate} />;
      case 'tips': return <TipsPage onNavigate={handleNavigate} />;
      case 'contact': return <ContactPage onNavigate={handleNavigate} />;
      case 'terms': return <TermsPage onNavigate={handleNavigate} />;
      case 'privacy': return <PrivacyPage onNavigate={handleNavigate} />;
      default: return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className={`min-h-screen bg-surface text-on-surface font-body selection:bg-primary-fixed selection:text-on-primary-fixed flex flex-col ${['buyer', 'seller', 'admin'].includes(currentView) ? 'h-screen overflow-hidden' : ''}`}>
      <ScrollToTop view={currentView} />
      <div className="flex-grow">
        {renderView()}
      </div>
      {currentView !== 'auth' && !['buyer', 'seller', 'admin'].includes(currentView) && <Footer onNavigate={handleNavigate} />}
      
      {/* Development Navigation Menu - Hidden in production/demo */}
      {/* 
      <div className={`fixed bottom-4 left-4 z-[100] bg-inverse-surface/90 backdrop-blur text-inverse-on-surface p-3 rounded-xl shadow-2xl flex flex-col gap-2 border border-outline-variant/20 transition-all duration-300 ${isDevNavMinimized ? 'h-10 w-40 overflow-hidden' : ''}`} dir="ltr">
        ...
      </div>
      */}
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </SettingsProvider>
  );
}
