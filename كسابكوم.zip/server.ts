import express, { Request, Response, NextFunction } from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import admin from "firebase-admin";
import fs from "fs";
import { Firestore, FieldValue, Timestamp } from '@google-cloud/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin (for Auth only)
const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId,
    credential: admin.credential.applicationDefault()
  });
}

// Initialize Firestore with named database
const db = new Firestore({
  projectId: firebaseConfig.projectId,
  databaseId: firebaseConfig.firestoreDatabaseId || '(default)',
});
const auth = admin.auth();

// Middleware: Verify Token
const verifyToken = async (req: any, res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: No token provided' });
  }
  const idToken = header.split('Bearer ')[1];
  try {
    const decodedToken = await auth.verifyIdToken(idToken);
    req.user = decodedToken;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};

// Middleware: Admin Only
const isAdmin = async (req: any, res: Response, next: NextFunction) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const userDocRef = doc(db, 'users', req.user.uid);
    const userDoc = await getDoc(userDocRef);
    const userData = userDoc.data();
    if (userData?.role === 'admin') {
      next();
    } else {
      res.status(403).json({ error: 'Forbidden: Admin access only' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error checking role' });
  }
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- PUBLIC ENDPOINTS ---

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // --- SETTINGS ENDPOINTS ---
  app.get("/api/settings", async (req, res) => {
    try {
      const snap = await db.collection('settings').get();
      const settings: any = {};
      snap.docs.forEach(doc => {
        settings[doc.id === 'global' ? 'main' : doc.id] = doc.data();
      });
      // Flatten global for simplicity or keep as is.
      // For now, return what we have.
      res.json(settings);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.put("/api/settings", verifyToken, isAdmin, async (req: any, res) => {
    try {
      const { collection = 'global', data } = req.body;
      await db.collection('settings').doc(collection).set(data, { merge: true });
      res.json({ status: "ok" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // --- STATS ---
  app.get("/api/stats", async (req, res) => {
    try {
      const usersSnap = await getDocs(collection(db, 'users'));
      const listingsSnap = await getDocs(query(collection(db, 'announcements'), where('status', '==', 'active')));
      const requestsSnap = await getDocs(collection(db, 'offerRequests'));
      
      res.json({
        totalUsers: usersSnap.size,
        activeListings: listingsSnap.size,
        totalRequests: requestsSnap.size,
        regionsCovered: 12,
        lastUpdated: new Date().toISOString()
      });
    } catch (e) {
      res.json({ totalUsers: 0, activeListings: 0, totalRequests: 0 });
    }
  });

  app.get("/api/market-trends", (req, res) => {
    res.json([
      { breed: "سردي", trend: "up", change: "+2.5%", avgPrice: 3200 },
      { breed: "بركي", trend: "stable", change: "0%", avgPrice: 2800 },
      { breed: "مستورد", trend: "down", change: "-1.2%", avgPrice: 3500 }
    ]);
  });

  app.get("/api/categories", (req, res) => {
    res.json(["سردي", "بركي", "تيمحضيت", "بني كيل", "دمّان", "إسباني", "روماني"]);
  });

  app.get("/api/cities", (req, res) => {
    res.json(["سطات", "برشيد", "خريبكة", "الدار البيضاء", "الرباط", "مراكش", "أزرو", "خنيفرة", "وجدة", "الراشيدية", "طنجة"]);
  });

  // --- AUTH & USER ENDPOINTS ---

  app.post("/api/auth/register", async (req, res) => {
    const { uid, email, fullName, role } = req.body;
    try {
      await setDoc(doc(db, 'users', uid), {
        email,
        fullName,
        role: role || 'buyer',
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });
      res.status(201).json({ message: "User profile created" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/auth/login", verifyToken, async (req: any, res) => {
    // Just sync/verify user exists
    const userDoc = await db.collection('users').doc(req.user.uid).get();
    if (!userDoc.exists) {
      await db.collection('users').doc(req.user.uid).set({
        email: req.user.email,
        fullName: req.user.name || 'مستخدم جديد',
        role: 'buyer',
        status: 'active',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }
    res.json({ status: "ok" });
  });

  app.get("/api/auth/me", verifyToken, async (req: any, res) => {
    const userDoc = await db.collection('users').doc(req.user.uid).get();
    if (!userDoc.exists) return res.status(404).json({ error: "User profile not found" });
    res.json({ id: userDoc.id, ...userDoc.data() });
  });

  app.get("/api/auth/check-phone/:phone", async (req, res) => {
    try {
      const snap = await db.collection('users').where('phoneNumber', '==', req.params.phone).limit(1).get();
      res.json({ exists: !snap.empty });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.put("/api/auth/profile", verifyToken, async (req: any, res) => {
    try {
      await db.collection('users').doc(req.user.uid).update({
        ...req.body,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
      res.json({ message: "Profile updated" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const doc = await db.collection('users').doc(req.params.id).get();
      if (!doc.exists) return res.status(404).json({ error: "Not found" });
      const data = doc.data() || {};
      res.json({ id: doc.id, ...data });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // --- LISTINGS ENDPOINTS ---

  app.get("/api/listings", async (req, res) => {
    const { category, sellerId } = req.query;
    let query: any = db.collection('announcements');
    if (category) query = query.where('category', '==', category);
    if (sellerId) query = query.where('sellerId', '==', sellerId);
    query = query.where('status', '==', 'active').orderBy('createdAt', 'desc');
    
    const snap = await query.limit(50).get();
    const data = snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }));
    res.json(data);
  });

  app.get("/api/listings/:id", async (req, res) => {
    const doc = await db.collection('announcements').doc(req.params.id).get();
    if (!doc.exists) return res.status(404).json({ error: "Not found" });
    res.json({ id: doc.id, ...doc.data() });
  });

  app.post("/api/listings", verifyToken, async (req: any, res) => {
    try {
      const data = {
        ...req.body,
        sellerId: req.user.uid,
        status: 'active',
        clicks: { phone: 0, whatsapp: 0 },
        totalClicks: 0,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };
      const docRef = await db.collection('announcements').add(data);
      res.status(201).json({ id: docRef.id });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.put("/api/listings/:id", verifyToken, async (req: any, res) => {
    const docRef = db.collection('announcements').doc(req.params.id);
    const snap = await docRef.get();
    if (!snap.exists) return res.status(404).json({ error: "Not found" });
    if (snap.data()?.sellerId !== req.user.uid) return res.status(403).json({ error: "Unauthorized" });

    await docRef.update({
      ...req.body,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.json({ status: "updated" });
  });

  app.delete("/api/listings/:id", verifyToken, async (req: any, res) => {
    const docRef = db.collection('announcements').doc(req.params.id);
    const snap = await docRef.get();
    if (!snap.exists) return res.status(404).json({ error: "Not found" });
    if (snap.data()?.sellerId !== req.user.uid) return res.status(403).json({ error: "Unauthorized" });

    await docRef.delete();
    res.json({ status: "deleted" });
  });

  app.get("/api/listings/seller/:sellerId", async (req, res) => {
    const snap = await db.collection('announcements')
      .where('sellerId', '==', req.params.sellerId)
      .orderBy('createdAt', 'desc')
      .get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/listings/:id/boost", verifyToken, async (req: any, res) => {
    await db.collection('announcements').doc(req.params.id).update({ boosted: true });
    res.json({ status: "ok" });
  });

  app.post("/api/listings/:id/rate", verifyToken, async (req: any, res) => {
    const { rating } = req.body;
    await db.collection('announcements').doc(req.params.id).update({ 
      rating: FieldValue.increment(rating),
      ratingCount: FieldValue.increment(1)
    });
    res.json({ status: "ok" });
  });

  // --- REQUESTS ENDPOINTS ---

  app.get("/api/requests", async (req, res) => {
    const snap = await db.collection('offerRequests').where('status', '==', 'Open').orderBy('createdAt', 'desc').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/requests", verifyToken, async (req: any, res) => {
    const data = {
      ...req.body,
      buyerId: req.user.uid,
      status: 'Open',
      offersCount: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    const docRef = await db.collection('offerRequests').add(data);
    res.status(201).json({ id: docRef.id });
  });

  app.get("/api/requests/:id", async (req, res) => {
    const doc = await db.collection('offerRequests').doc(req.params.id).get();
    if (!doc.exists) return res.status(404).json({ error: "Not found" });
    res.json({ id: doc.id, ...doc.data() });
  });

  app.put("/api/requests/:id/archive", verifyToken, async (req: any, res) => {
    await db.collection('offerRequests').doc(req.params.id).update({ status: 'archived' });
    res.json({ status: "ok" });
  });

  app.delete("/api/requests/:id", verifyToken, async (req: any, res) => {
    const docRef = db.collection('offerRequests').doc(req.params.id);
    const snap = await docRef.get();
    if (!snap.exists) return res.status(404).json({ error: "Not found" });
    if (snap.data()?.buyerId !== req.user.uid) return res.status(403).json({ error: "Unauthorized" });

    await docRef.delete();
    res.json({ status: "deleted" });
  });

  // --- OFFERS ENDPOINTS ---

  app.post("/api/offers", verifyToken, async (req: any, res) => {
    const { requestId, price, message, deliveryIncluded } = req.body;
    const requestRef = db.collection('offerRequests').doc(requestId);
    
    try {
      await db.runTransaction(async (transaction) => {
        const requestSnap = await transaction.get(requestRef);
        if (!requestSnap.exists) throw new Error("Request not found");
        
        const requestData = requestSnap.data();
        if (requestData?.offersCount >= 6) throw new Error("Maximum offers reached (6)");

        const offerRef = db.collection('offers').doc();
        transaction.set(offerRef, {
          requestId,
          sellerId: req.user.uid,
          price,
          message,
          deliveryIncluded,
          status: 'pending',
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });

        transaction.update(requestRef, {
          offersCount: FieldValue.increment(1)
        });
      });
      res.status(201).json({ status: "ok" });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.get("/api/offers/request/:requestId", verifyToken, async (req: any, res) => {
    const snap = await db.collection('offers')
      .where('requestId', '==', req.params.requestId)
      .orderBy('createdAt', 'desc')
      .get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.put("/api/offers/:id/accept", verifyToken, async (req: any, res) => {
    const offerRef = db.collection('offers').doc(req.params.id);
    const offerSnap = await offerRef.get();
    if (!offerSnap.exists) return res.status(404).json({ error: "Not found" });
    
    const offerData = offerSnap.data();
    const requestRef = db.collection('offerRequests').doc(offerData?.requestId);
    const requestSnap = await requestRef.get();
    
    if (requestSnap.data()?.buyerId !== req.user.uid) return res.status(403).json({ error: "Unauthorized" });

    await db.runTransaction(async (transaction) => {
      transaction.update(offerRef, { status: 'accepted' });
      transaction.update(requestRef, { status: 'Closed' });
      
      // Update listing stock or count if needed
      if (offerData?.listingId) {
        transaction.update(db.collection('announcements').doc(offerData.listingId), {
          sheepCount: FieldValue.increment(-(offerData.sheepCount || 0))
        });
      }
    });
    res.json({ status: "accepted" });
  });

  app.put("/api/offers/:id/status", verifyToken, async (req: any, res) => {
    await db.collection('offers').doc(req.params.id).update({ status: req.body.status });
    res.json({ status: "ok" });
  });

  app.delete("/api/offers/:id", verifyToken, async (req: any, res) => {
    await db.collection('offers').doc(req.params.id).delete();
    res.json({ status: "ok" });
  });

  // --- FAVORITES ENDPOINTS ---

  app.get("/api/favorites", verifyToken, async (req: any, res) => {
    const snap = await db.collection('users').doc(req.user.uid).collection('favorites').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/favorites", verifyToken, async (req: any, res) => {
    const { listingId } = req.body;
    await db.collection('users').doc(req.user.uid).collection('favorites').doc(listingId).set({
      listingId,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.json({ status: "ok" });
  });

  app.delete("/api/favorites/:listingId", verifyToken, async (req: any, res) => {
    await db.collection('users').doc(req.user.uid).collection('favorites').doc(req.params.listingId).delete();
    res.json({ status: "ok" });
  });

  // --- REPORTS ENDPOINTS ---

  app.post("/api/reports", verifyToken, async (req: any, res) => {
    const data = {
      ...req.body,
      reporterId: req.user.uid,
      status: 'pending',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await db.collection('reports').add(data);
    res.json({ status: "ok" });
  });

  app.post("/api/donations", verifyToken, async (req: any, res) => {
    const data = {
      ...req.body,
      donorId: req.user.uid,
      status: 'pending',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await db.collection('donations').add(data);
    res.json({ status: "ok" });
  });

  app.post("/api/users/:sellerId/reviews", verifyToken, async (req: any, res) => {
    const data = {
      ...req.body,
      authorId: req.user.uid,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    await db.collection('users').doc(req.params.sellerId).collection('reviews').add(data);
    res.json({ status: "ok" });
  });

  app.delete("/api/users/:sellerId/reviews/:reviewId", verifyToken, async (req: any, res) => {
    await db.collection('users').doc(req.params.sellerId).collection('reviews').doc(req.params.reviewId).delete();
    res.json({ status: "ok" });
  });

  // --- ADMIN ENDPOINTS ---

  app.get("/api/admin/users", verifyToken, isAdmin, async (req, res) => {
    const snap = await db.collection('users').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/admin/users/:userId/notify", verifyToken, isAdmin, async (req, res) => {
    const notification = {
      ...req.body,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      read: false
    };
    await db.collection('users').doc(req.params.userId).collection('notifications').add(notification);
    res.json({ status: "ok" });
  });

  app.put("/api/admin/users/:id/verify", verifyToken, isAdmin, async (req, res) => {
    await db.collection('users').doc(req.params.id).update({ isVerified: true });
    res.json({ status: "ok" });
  });

  app.put("/api/admin/users/:id/status", verifyToken, isAdmin, async (req, res) => {
    await db.collection('users').doc(req.params.id).update({ status: req.body.status });
    res.json({ status: "ok" });
  });

  app.delete("/api/admin/users/:id", verifyToken, isAdmin, async (req, res) => {
    await db.collection('users').doc(req.params.id).delete();
    res.json({ status: "ok" });
  });

  app.put("/api/admin/users/:id/ban", verifyToken, isAdmin, async (req, res) => {
    await db.collection('users').doc(req.params.id).update({ status: 'blocked' });
    res.json({ status: "ok" });
  });

  app.get("/api/admin/listings", verifyToken, isAdmin, async (req, res) => {
    const snap = await db.collection('announcements').orderBy('createdAt', 'desc').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/admin/listings/import", verifyToken, isAdmin, async (req: any, res) => {
    const { data } = req.body;
    const batch = db.batch();
    data.forEach((item: any) => {
      const ref = db.collection('announcements').doc();
      batch.set(ref, { 
        ...item, 
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        status: 'active'
      });
    });
    await batch.commit();
    res.json({ status: "ok" });
  });

  app.put("/api/admin/listings/:id/approve", verifyToken, isAdmin, async (req, res) => {
    await db.collection('announcements').doc(req.params.id).update({ status: 'active' });
    res.json({ status: "ok" });
  });

  app.put("/api/admin/listings/:id/status", verifyToken, isAdmin, async (req, res) => {
    const { status, reason } = req.body;
    const updateData: any = { status };
    if (reason) updateData.rejectReason = reason;
    await db.collection('announcements').doc(req.params.id).update(updateData);
    res.json({ status: "ok" });
  });

  app.delete("/api/admin/listings/:id", verifyToken, isAdmin, async (req, res) => {
    await db.collection('announcements').doc(req.params.id).delete();
    res.json({ status: "ok" });
  });

  app.get("/api/admin/reports", verifyToken, isAdmin, async (req, res) => {
    const snap = await db.collection('reports').orderBy('createdAt', 'desc').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.put("/api/admin/reports/:id/status", verifyToken, isAdmin, async (req, res) => {
    await db.collection('reports').doc(req.params.id).update({ status: req.body.status });
    res.json({ status: "ok" });
  });

  app.delete("/api/admin/reports/:id", verifyToken, isAdmin, async (req, res) => {
    await db.collection('reports').doc(req.params.id).delete();
    res.json({ status: "ok" });
  });

  app.post("/api/admin/system-reset", verifyToken, isAdmin, async (req, res) => {
    try {
      const collections = ['announcements', 'offerRequests', 'offers', 'reports', 'donations', 'adminLogs'];
      for (const coll of collections) {
        const snap = await db.collection(coll).get();
        const batch = db.batch();
        snap.docs.forEach(doc => batch.delete(doc.ref));
        await batch.commit();
      }
      
      // Cleanup users but keep the caller
      const usersSnap = await db.collection('users').get();
      const userBatch = db.batch();
      usersSnap.docs.forEach(doc => {
        if (doc.id !== (req as any).user.uid) userBatch.delete(doc.ref);
      });
      await userBatch.commit();

      res.json({ status: "ok" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/admin/donations", verifyToken, isAdmin, async (req, res) => {
    const snap = await db.collection('donations').orderBy('createdAt', 'desc').get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.get("/api/admin/export", verifyToken, isAdmin, async (req, res) => {
    const { collection } = req.query;
    if (!collection) return res.status(400).json({ error: "No collection specified" });
    const snap = await db.collection(collection as string).get();
    res.json(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  });

  app.get("/api/admin/logs", verifyToken, isAdmin, async (req, res) => {
    const snap = await db.collection('adminLogs').orderBy('createdAt', 'desc').limit(200).get();
    res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  });

  app.post("/api/reports", verifyToken, async (req: any, res) => {
    try {
      const data = {
        ...req.body,
        reporterId: req.user.uid,
        status: 'pending',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };
      await db.collection('reports').add(data);
      res.status(201).json({ status: "ok" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/donations", async (req, res) => {
    try {
      const data = {
        ...req.body,
        status: 'pending',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };
      await db.collection('donations').add(data);
      res.status(201).json({ status: "ok" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post("/api/clicks", verifyToken, async (req: any, res) => {
    const { listingId, type } = req.body;
    try {
      const docRef = db.collection('announcements').doc(listingId);
      await docRef.update({
        [`clicks.${type}`]: admin.firestore.FieldValue.increment(1),
        totalClicks: admin.firestore.FieldValue.increment(1)
      });
      res.json({ status: "ok" });
    } catch (e) {
      res.status(500).json({ error: "Failed to log click" });
    }
  });

  app.post("/api/notifications", verifyToken, async (req: any, res) => {
    try {
      const { userId, title, message, type, relatedId } = req.body;
      const data = {
        title,
        message,
        type,
        relatedId,
        read: false,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };
      await db.collection('users').doc(userId).collection('notifications').add(data);
      res.status(201).json({ status: "ok" });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/notifications", verifyToken, async (req: any, res) => {
    try {
      const snap = await db.collection('users').doc(req.user.uid).collection('notifications')
        .orderBy('createdAt', 'desc')
        .limit(50)
        .get();
      res.json(snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.put("/api/notifications/:id/read", verifyToken, async (req: any, res) => {
    try {
      await db.collection('users').doc(req.user.uid).collection('notifications').doc(req.params.id).update({
        isRead: true
      });
      res.json({ status: "ok" });
    } catch (e) {
      res.status(500).json({ error: "Failed to mark as read" });
    }
  });

  // --- VITE MIDDLEWARE ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.use((req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
